from getpass import getpass
import mysql.connector
from werkzeug.security import generate_password_hash
from config import DB_CONFIG

conn = mysql.connector.connect(**DB_CONFIG)
cur = conn.cursor()
username = input("Administrator username: ").strip()
email = input("Administrator email (optional): ").strip() or None
password = getpass("Create administrator password: ")
confirm = getpass("Confirm password: ")
if not username or len(password) < 8 or password != confirm:
    raise SystemExit("Username is required; passwords must match and contain at least 8 characters.")
cur.execute("INSERT INTO users (username,password_hash,email,role) VALUES (%s,%s,%s,'Administrator')",
            (username, generate_password_hash(password), email))
conn.commit()
cur.close(); conn.close()
print("Administrator account created. You can now log in.")
