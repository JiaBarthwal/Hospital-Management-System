from functools import wraps
from datetime import date
from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from mysql.connector import Error
from werkzeug.security import check_password_hash
from config import DB_CONFIG, SECRET_KEY

app = Flask(__name__)
app.secret_key = SECRET_KEY

@app.context_processor
def inject_modules():
    return {"modules": MODULES}

MODULES = {
    "patients": {
        "title": "Patients", "table": "patients", "pk": "patient_id",
        "fields": [
            ("first_name","First name","text",True),("last_name","Last name","text",False),
            ("date_of_birth","Date of birth","date",False),("gender","Gender","select:Male,Female,Other",False),
            ("phone","Phone","text",True),("email","Email","email",False),("address","Address","textarea",False),
            ("blood_group","Blood group","select:A+,A-,B+,B-,AB+,AB-,O+,O-",False),
            ("emergency_contact","Emergency contact","text",False)],
        "roles": ["Administrator","Receptionist"]
    },
    "doctors": {
        "title": "Doctors", "table": "doctors", "pk": "doctor_id",
        "fields": [("full_name","Full name","text",True),("specialization","Specialization","text",False),
                   ("phone","Phone","text",False),("email","Email","email",False),("availability","Availability","text",False)],
        "roles": ["Administrator"]
    },
    "staff": {
        "title": "Staff", "table": "staff", "pk": "staff_id",
        "fields": [("full_name","Full name","text",True),("designation","Designation","text",False),
                   ("phone","Phone","text",False),("email","Email","email",False)],
        "roles": ["Administrator"]
    },
    "appointments": {
        "title": "Appointments", "table": "appointments", "pk": "appointment_id",
        "fields": [("patient_id","Patient ID","number",True),("doctor_id","Doctor ID","number",True),
                   ("appointment_date","Date","date",True),("appointment_time","Time","time",True),
                   ("status","Status","select:Scheduled,Completed,Cancelled",False),("notes","Notes","textarea",False)],
        "roles": ["Administrator","Receptionist","Doctor"]
    },
    "medical_records": {
        "title": "Medical Records", "table": "medical_records", "pk": "record_id",
        "fields": [("patient_id","Patient ID","number",True),("doctor_id","Doctor ID","number",False),
                   ("visit_date","Visit date","date",True),("diagnosis","Diagnosis","textarea",False),
                   ("treatment","Treatment","textarea",False),("notes","Notes","textarea",False)],
        "roles": ["Administrator","Doctor"]
    },
    "medicines": {
        "title": "Medicines", "table": "medicines", "pk": "medicine_id",
        "fields": [("medicine_name","Medicine name","text",True),("category","Category","text",False),
                   ("stock_quantity","Stock quantity","number",False),("unit_price","Unit price","number",False),
                   ("expiry_date","Expiry date","date",False)],
        "roles": ["Administrator","Billing Staff"]
    },
    "prescriptions": {
        "title": "Prescriptions", "table": "prescriptions", "pk": "prescription_id",
        "fields": [("patient_id","Patient ID","number",True),("doctor_id","Doctor ID","number",False),
                   ("medicine_id","Medicine ID","number",False),("dosage","Dosage","text",False),
                   ("duration","Duration","text",False),("instructions","Instructions","textarea",False),
                   ("prescribed_on","Prescribed on","date",True)],
        "roles": ["Administrator","Doctor"]
    },
    "rooms": {
        "title": "Rooms", "table": "rooms", "pk": "room_id",
        "fields": [("room_number","Room number","text",True),("room_type","Room type","text",False),
                   ("floor_number","Floor","text",False),("status","Status","select:Available,Occupied,Maintenance",False)],
        "roles": ["Administrator","Receptionist"]
    },
    "beds": {
        "title": "Beds", "table": "beds", "pk": "bed_id",
        "fields": [("room_id","Room ID","number",True),("bed_number","Bed number","text",True),
                   ("status","Status","select:Available,Occupied,Maintenance",False)],
        "roles": ["Administrator","Receptionist"]
    },
    "billing": {
        "title": "Billing", "table": "billing", "pk": "bill_id",
        "fields": [("patient_id","Patient ID","number",True),("bill_date","Bill date","date",True),
                   ("description","Description","textarea",False),("total_amount","Total amount","number",True),
                   ("status","Status","select:Unpaid,Partially Paid,Paid",False)],
        "roles": ["Administrator","Billing Staff"]
    },
    "payments": {
        "title": "Payments", "table": "payments", "pk": "payment_id",
        "fields": [("bill_id","Bill ID","number",True),("payment_date","Payment date","date",True),
                   ("amount","Amount","number",True),("payment_method","Payment method","select:Cash,Card,UPI,Online",False),
                   ("reference_number","Reference number","text",False)],
        "roles": ["Administrator","Billing Staff"]
    }
}

def db():
    return mysql.connector.connect(**DB_CONFIG)

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def role_required(roles):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))
            if session.get("role") not in roles:
                flash("You do not have permission to access that section.", "error")
                return redirect(url_for("dashboard"))
            return fn(*args, **kwargs)
        return wrapper
    return decorator

@app.route("/")
def home():
    return redirect(url_for("dashboard") if "user_id" in session else url_for("login"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        conn = db()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT * FROM users WHERE username=%s", (username,))
        user = cur.fetchone()
        cur.close(); conn.close()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session.update(user_id=user["user_id"], username=user["username"], role=user["role"])
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    counts = {}
    conn = db(); cur = conn.cursor()
    for key, table in [("patients","patients"),("doctors","doctors"),("appointments","appointments"),
                       ("staff","staff"),("waiting","patient_queue")]:
        cur.execute(f"SELECT COUNT(*) FROM {table}")
        counts[key] = cur.fetchone()[0]
    cur.close(); conn.close()
    return render_template("dashboard.html", counts=counts, modules=MODULES)

@app.route("/module/<name>", methods=["GET","POST"])
@login_required
def module(name):
    if name not in MODULES:
        return "Module not found", 404
    cfg = MODULES[name]
    if session.get("role") not in cfg["roles"]:
        flash("You do not have permission to access this module.", "error")
        return redirect(url_for("dashboard"))
    conn = db(); cur = conn.cursor(dictionary=True)
    if request.method == "POST":
        cols, vals = [], []
        for field, label, kind, required in cfg["fields"]:
            value = request.form.get(field) or None
            if required and not value:
                flash(f"{label} is required.", "error")
                cur.close(); conn.close()
                return redirect(url_for("module", name=name))
            cols.append(field); vals.append(value)
        placeholders = ",".join(["%s"] * len(cols))
        sql = f"INSERT INTO {cfg['table']} ({','.join(cols)}) VALUES ({placeholders})"
        try:
            cur.execute(sql, vals); conn.commit()
            flash(f"{cfg['title']} record added successfully.", "success")
        except Error as e:
            conn.rollback(); flash(f"Could not save record: {e.msg}", "error")
        cur.close(); conn.close()
        return redirect(url_for("module", name=name))
    cur.execute(f"SELECT * FROM {cfg['table']} ORDER BY {cfg['pk']} DESC LIMIT 300")
    rows = cur.fetchall()
    cur.close(); conn.close()
    return render_template("module.html", name=name, cfg=cfg, rows=rows)

@app.post("/module/<name>/delete/<int:record_id>")
@login_required
def delete_record(name, record_id):
    if name not in MODULES or session.get("role") != "Administrator":
        flash("Only an Administrator can delete records.", "error")
        return redirect(url_for("dashboard"))
    cfg = MODULES[name]
    conn = db(); cur = conn.cursor()
    try:
        cur.execute(f"DELETE FROM {cfg['table']} WHERE {cfg['pk']}=%s", (record_id,))
        conn.commit()
        flash("Record deleted.", "success")
    except Error as e:
        conn.rollback(); flash(f"Cannot delete this record because it may be linked to another record: {e.msg}", "error")
    cur.close(); conn.close()
    return redirect(url_for("module", name=name))

@app.route("/queue", methods=["GET","POST"])
@login_required
def queue():
    if session.get("role") not in ["Administrator","Receptionist","Doctor"]:
        flash("You do not have permission to access the queue.", "error")
        return redirect(url_for("dashboard"))
    conn = db(); cur = conn.cursor(dictionary=True)
    if request.method == "POST":
        patient_id = request.form.get("patient_id")
        doctor_id = request.form.get("doctor_id") or None
        priority = request.form.get("priority","Normal")
        cur2 = conn.cursor()
        cur2.execute("SELECT COALESCE(MAX(token_number),0)+1 FROM patient_queue")
        token = cur2.fetchone()[0]
        cur2.execute("INSERT INTO patient_queue (patient_id,doctor_id,token_number,priority) VALUES (%s,%s,%s,%s)",
                     (patient_id,doctor_id,token,priority))
        conn.commit(); cur2.close()
        flash(f"Patient added to queue. Token number: {token}", "success")
        cur.close(); conn.close()
        return redirect(url_for("queue"))
    cur.execute("""SELECT q.*, p.first_name, p.last_name, d.full_name AS doctor_name
                   FROM patient_queue q JOIN patients p ON q.patient_id=p.patient_id
                   LEFT JOIN doctors d ON q.doctor_id=d.doctor_id
                   WHERE q.status IN ('Waiting','In Progress')
                   ORDER BY (q.priority='Emergency') DESC, q.added_at ASC""")
    rows = cur.fetchall()
    cur.execute("SELECT patient_id, first_name, last_name FROM patients ORDER BY first_name")
    patients = cur.fetchall()
    cur.execute("SELECT doctor_id, full_name FROM doctors ORDER BY full_name")
    doctors = cur.fetchall()
    # Simple estimate: 15 minutes per waiting patient ahead; emergency cases are prioritized.
    for i, row in enumerate(rows):
        row["estimated_wait"] = i * 15
    cur.close(); conn.close()
    return render_template("queue.html", rows=rows, patients=patients, doctors=doctors)

@app.post("/queue/status/<int:queue_id>")
@login_required
def queue_status(queue_id):
    if session.get("role") not in ["Administrator","Receptionist","Doctor"]:
        return redirect(url_for("dashboard"))
    status = request.form.get("status")
    if status not in ["Waiting","In Progress","Completed","Cancelled"]:
        return redirect(url_for("queue"))
    conn = db(); cur = conn.cursor()
    cur.execute("UPDATE patient_queue SET status=%s WHERE queue_id=%s", (status,queue_id))
    conn.commit(); cur.close(); conn.close()
    return redirect(url_for("queue"))

@app.errorhandler(500)
def server_error(error):
    return render_template("error.html"), 500

if __name__ == "__main__":
    app.run(debug=True)
