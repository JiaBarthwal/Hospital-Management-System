# Add your MySQL credentials here. Do not share this file or your password.
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "YOUR_MYSQL_PASSWORD",
    "database": "hospital_management_system",
}
SECRET_KEY = "change-this-to-a-long-random-secret-key"
