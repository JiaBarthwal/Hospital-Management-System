HOSPITAL MANAGEMENT SYSTEM - FINAL STARTER PACKAGE

IMPORTANT
- This is a complete academic project starter with working Flask/MySQL modules.
- It uses a NEW database named hospital_management_system, so your existing hospital_db database is not overwritten.
- The waiting-time predictor is a simple academic estimate (15 minutes per patient ahead), not a clinically validated prediction.
- Do not use this demo with real patient data or in a real hospital without professional security, privacy, audit, and clinical review.

SETUP (Windows / VS Code)

1. Extract this ZIP to your Desktop.
2. Open the extracted Hospital_Management_System_Final folder in VS Code.
3. Open config.py and replace YOUR_MYSQL_PASSWORD with your MySQL root password locally. Do not send the password to anyone.
4. Open PowerShell in this folder and run:
   py -3.11 -m venv venv
   .\venv\Scripts\python.exe -m pip install -r requirements.txt

5. Create the database and tables. In MySQL Command Line Client, open schema.sql and run its SQL commands, OR run:
   mysql -u root -p < schema.sql
   (If the mysql command is not recognized, use MySQL Command Line Client and paste the contents of schema.sql.)

6. Create the first Administrator account:
   .\venv\Scripts\python.exe bootstrap_admin.py
   Enter a username and a password of at least 8 characters. Password input is hidden.

7. Start the application:
   .\venv\Scripts\python.exe app.py

8. Open in your browser:
   http://127.0.0.1:5000

ROLE ACCESS
- Administrator: all modules and record deletion
- Receptionist: patients, appointments, rooms, beds, queue
- Doctor: appointments, medical records, prescriptions, queue
- Billing Staff: medicines, billing, payments
- Patient: login role is defined; patient self-service pages are not implemented in this academic version.

DATA ENTRY NOTES
- Use numeric IDs shown in the related module for linked records:
  appointments: patient_id and doctor_id
  medical records: patient_id and doctor_id
  prescriptions: patient_id, doctor_id, medicine_id
  beds: room_id
  billing: patient_id
  payments: bill_id
- Add patients and doctors before creating linked records.
- Deletion is restricted to Administrator and MySQL foreign keys prevent deleting linked records.

TROUBLESHOOTING
- Access denied: verify MySQL is running and credentials in config.py.
- Unknown database: run schema.sql.
- Module not found / template error: make sure you extracted the whole ZIP and opened the project root folder.
- Port in use: close the other Flask terminal or change app.run(port=5001).

SECURITY LIMITATIONS
This is a student project, not production software. Before any real deployment add HTTPS, CSRF protection, session timeout, audit logging, strong secret management, input validation, backups, privacy controls, and security testing. Do not store real patient data.
